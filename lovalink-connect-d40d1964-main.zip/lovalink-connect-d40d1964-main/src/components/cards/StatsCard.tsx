import { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  gradient?: string;
}

export const StatsCard = ({
  title,
  value,
  icon: Icon,
  trend,
  gradient = "gradient-primary",
}: StatsCardProps) => {
  return (
    <Card className="p-6 shadow-soft hover:shadow-medium transition-smooth">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <h3 className="text-3xl font-bold">{value}</h3>
          {trend && (
            <p className="text-sm text-success-foreground mt-1">{trend}</p>
          )}
        </div>
        <div className={`h-14 w-14 rounded-xl ${gradient} flex items-center justify-center`}>
          <Icon className="h-7 w-7 text-white" />
        </div>
      </div>
    </Card>
  );
};
