import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import StudentDashboard from "./pages/student/StudentDashboard";
import StudentProfile from "./pages/student/StudentProfile";
import StudentAlumni from "./pages/student/StudentAlumni";
import StudentEvents from "./pages/student/StudentEvents";
import StudentJobs from "./pages/student/StudentJobs";
import StudentScholarships from "./pages/student/StudentScholarships";
import StudentSettings from "./pages/student/StudentSettings";
import StudentHelp from "./pages/student/StudentHelp";
import AlumniDashboard from "./pages/alumni/AlumniDashboard";
import AlumniProfile from "./pages/alumni/AlumniProfile";
import AlumniDirectory from "./pages/alumni/AlumniDirectory";
import AlumniEvents from "./pages/alumni/AlumniEvents";
import AlumniMessages from "./pages/alumni/AlumniMessages";
import AlumniSettings from "./pages/alumni/AlumniSettings";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ManageStudents from "./pages/admin/ManageStudents";
import ManageAlumni from "./pages/admin/ManageAlumni";
import ManageEvents from "./pages/admin/ManageEvents";
import AdminReports from "./pages/admin/AdminReports";
import AdminSettings from "./pages/admin/AdminSettings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          
          {/* Student Portal Routes */}
          <Route path="/student/dashboard" element={<StudentDashboard />} />
          <Route path="/student/profile" element={<StudentProfile />} />
          <Route path="/student/alumni" element={<StudentAlumni />} />
          <Route path="/student/events" element={<StudentEvents />} />
          <Route path="/student/jobs" element={<StudentJobs />} />
          <Route path="/student/scholarships" element={<StudentScholarships />} />
          <Route path="/student/settings" element={<StudentSettings />} />
          <Route path="/student/help" element={<StudentHelp />} />
          
          {/* Alumni Portal Routes */}
          <Route path="/alumni/dashboard" element={<AlumniDashboard />} />
          <Route path="/alumni/profile" element={<AlumniProfile />} />
          <Route path="/alumni/directory" element={<AlumniDirectory />} />
          <Route path="/alumni/events" element={<AlumniEvents />} />
          <Route path="/alumni/messages" element={<AlumniMessages />} />
          <Route path="/alumni/settings" element={<AlumniSettings />} />
          
          {/* Admin Portal Routes */}
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/students" element={<ManageStudents />} />
          <Route path="/admin/alumni" element={<ManageAlumni />} />
          <Route path="/admin/events" element={<ManageEvents />} />
          <Route path="/admin/reports" element={<AdminReports />} />
          <Route path="/admin/settings" element={<AdminSettings />} />
          
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
